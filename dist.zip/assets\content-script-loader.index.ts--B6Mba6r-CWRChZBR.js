(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.ts--B6Mba6r.js")
    );
  })().catch(console.error);

})();
